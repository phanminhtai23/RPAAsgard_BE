import { Stagehand } from "@browserbasehq/stagehand";
import {
    ApiGatewayManagementApiClient,
    PostToConnectionCommand,
} from "@aws-sdk/client-apigatewaymanagementapi";

/**
 * AWS Lambda WebSocket Handler cho API Gateway WebSocket
 * Nhận dữ liệu từ WebSocket client và stream logs real-time
 */

// Global variables cho connection tracking
let apiGatewayClient = null;

/**
 * Main Lambda Handler cho WebSocket events
 * @param {Object} event - API Gateway WebSocket event
 * @param {Object} context - Lambda context
 * @returns {Object} Response object
 */
export const handler = async (event, context) => {
    console.log("🚀 WebSocket Lambda Handler Started");
    console.log("Event:", JSON.stringify(event, null, 2));

    const { requestContext, body } = event;
    const { connectionId, routeKey, domainName, stage } = requestContext;

    // Initialize API Gateway Management API client
    if (!apiGatewayClient) {
        // Check if we're in test environment
        if (global.mockApiGatewayClient) {
            console.log("🧪 Using mock API Gateway client for testing");
            apiGatewayClient = global.mockApiGatewayClient;
        } else {
            const endpoint = `https://${domainName}/${stage}`;
            console.log(`🌐 Creating API Gateway client for: ${endpoint}`);
            apiGatewayClient = new ApiGatewayManagementApiClient({
                endpoint: endpoint,
            });
        }
    }

    try {
        switch (routeKey) {
            case "$connect":
                return await handleConnect(connectionId);

            case "$disconnect":
                return await handleDisconnect(connectionId);

            case "stagehand":
            case "$default":
                return await handleStagehandExecution(connectionId, body);

            default:
                console.log(`Unknown route: ${routeKey}`);
                return createResponse(400, { error: "Unknown route" });
        }
    } catch (error) {
        console.error("💥 Handler Error:", error);

        // Send error to client if possible
        await sendToClient(connectionId, {
            type: "error",
            error: error.message,
            timestamp: new Date().toISOString(),
        });

        return createResponse(500, { error: "Internal server error" });
    }
};

/**
 * Handle WebSocket connection
 */
async function handleConnect(connectionId) {
    console.log(`🔗 Client connected: ${connectionId}`);

    // Send welcome message
    await sendToClient(connectionId, {
        type: "connection",
        message: "Connected to Stagehand WebSocket",
        connectionId: connectionId,
        timestamp: new Date().toISOString(),
    });

    return createResponse(200, { message: "Connected" });
}

/**
 * Handle WebSocket disconnection
 */
async function handleDisconnect(connectionId) {
    console.log(`🔌 Client disconnected: ${connectionId}`);
    return createResponse(200, { message: "Disconnected" });
}

/**
 * Handle Stagehand execution with real-time streaming
 */
async function handleStagehandExecution(connectionId, body) {
    console.log(
        `🎯 Processing Stagehand request for connection: ${connectionId}`
    );

    try {
        // Parse incoming data
        const data = typeof body === "string" ? JSON.parse(body) : body;
        const { cdpUrl, workflow, options = {} } = data;

        // Validate input
        if (!workflow || !Array.isArray(workflow) || workflow.length === 0) {
            await sendToClient(connectionId, {
                type: "error",
                error: "Workflow is required and must be a non-empty array",
                timestamp: new Date().toISOString(),
            });
            return createResponse(400, { error: "Invalid workflow" });
        }

        if (
            !cdpUrl ||
            (!cdpUrl.startsWith("ws://") && !cdpUrl.startsWith("wss://"))
        ) {
            await sendToClient(connectionId, {
                type: "error",
                error: "Valid cdpUrl is required (ws:// or wss://)",
                timestamp: new Date().toISOString(),
            });
            return createResponse(400, { error: "Invalid cdpUrl" });
        }

        // Send start notification
        // await sendToClient(connectionId, {
        //     type: "start",
        //     message: `Starting workflow with ${workflow.length} steps`,
        //     workflow: workflow,
        //     timestamp: new Date().toISOString(),
        // });

        // Execute workflow with streaming
        const results = await executeStagehandWorkflowWithStreaming(
            connectionId,
            cdpUrl,
            workflow,
            options
        );

        // Send completion summary
        const totalSteps = results.length;
        const successfulSteps = results.filter(
            (r) => r.status === "success"
        ).length;
        const failedSteps = totalSteps - successfulSteps;

        await sendToClient(connectionId, {
            type: "complete",
            message: "Workflow execution completed",
            summary: {
                totalSteps,
                successfulSteps,
                failedSteps,
            },
            results: results,
            timestamp: new Date().toISOString(),
        });

        return createResponse(200, { message: "Execution completed" });
    } catch (error) {
        console.error("💥 Execution Error:", error);

        await sendToClient(connectionId, {
            type: "error",
            error: error.message,
            timestamp: new Date().toISOString(),
        });

        return createResponse(500, { error: error.message });
    }
}

/**
 * Execute Stagehand workflow với real-time streaming logs
 */
async function executeStagehandWorkflowWithStreaming(
    connectionId,
    cdpUrl,
    workflow,
    options = {}
) {
    let stagehand = null;
    let isInitialized = false;
    const results = [];

    try {
        // Stream log: Starting initialization
        // await sendToClient(connectionId, {
        //     type: "log",
        //     message: `🔗 Connecting to browser: ${cdpUrl}`,
        //     timestamp: new Date().toISOString(),
        // });

        // Configure Stagehand cho Lambda WebSocket
        const stagehandConfig = {
            verbose: 1, // Silent console logs, use custom logger
            domSettleTimeoutMs: 30000,

            // Custom logger để stream logs
            logger: async (logLine) => {
                await sendToClient(connectionId, {
                    type: "log",
                    message: logLine,
                    timestamp: new Date().toISOString(),
                });
            },

            // LLM config
            modelName: "google/gemini-2.0-flash",
            modelClientOptions: {
                apiKey: process.env.GOOGLE_API_KEY || "dummy-key",
            },

            // Browser config
            env: "LOCAL",
            enableCaching: false,
            headless: true,

            // External browser connection
            localBrowserLaunchOptions: {
                cdpUrl: cdpUrl,
                viewport: {
                    width: 1024,
                    height: 768,
                },
                args: [
                    "--no-sandbox",
                    "--disable-setuid-sandbox",
                    "--disable-dev-shm-usage",
                    "--disable-gpu",
                    "--disable-web-security",
                    "--disable-features=VizDisplayCompositor",
                    "--memory-pressure-off",
                    "--max_old_space_size=512",
                ],
            },

            logInferenceToFile: false,
            ...options,
        };

        // Initialize với timeout và streaming
        // await sendToClient(connectionId, {
        //     type: "log",
        //     message: "🔧 Initializing Stagehand...",
        //     timestamp: new Date().toISOString(),
        // });

        const initTimeout = new Promise((_, reject) => {
            setTimeout(
                () => reject(new Error("Browser connection timeout (60s)")),
                60000
            );
        });

        const initPromise = (async () => {
            stagehand = new Stagehand(stagehandConfig);
            await stagehand.init();
            return stagehand;
        })();

        stagehand = await Promise.race([initPromise, initTimeout]);
        isInitialized = true;

        // await sendToClient(connectionId, {
        //     type: "log",
        //     message: "✅ Browser connected successfully",
        //     timestamp: new Date().toISOString(),
        // });

        const page = stagehand.page;

        // Execute workflow với streaming per step
        for (let i = 0; i < workflow.length; i++) {
            const jsonData = workflow[i];
            let stepStatus = "success";
            let stepError = null;
            let stepData = null;
            const stepStartTime = Date.now();

            // Stream step start
            // await sendToClient(connectionId, {
            //     type: "step_start",
            //     step: i + 1,
            //     total: workflow.length,
            //     action:
            //         jsonData.action || jsonData.method || jsonData.description,
            //     timestamp: new Date().toISOString(),
            // });

            try {
                // Execute step với timeout
                const stepTimeout = new Promise((_, reject) => {
                    setTimeout(
                        () => reject(new Error("Step timeout (20s)")),
                        20000
                    );
                });

                const stepPromise = executeStepSafe(page, jsonData);
                await Promise.race([stepPromise, stepTimeout]);

                stepData = {
                    action:
                        jsonData.action ||
                        jsonData.method ||
                        jsonData.description,
                    executionTime: Date.now() - stepStartTime,
                };

                // Stream step success
                // await sendToClient(connectionId, {
                //     type: "step_complete",
                //     step: i + 1,
                //     status: "success",
                //     executionTime: Date.now() - stepStartTime,
                //     timestamp: new Date().toISOString(),
                // });
            } catch (err) {
                stepStatus = "error";
                stepError = err.message;

                // Stream step error
                // await sendToClient(connectionId, {
                //     type: "step_complete",
                //     step: i + 1,
                //     status: "error",
                //     error: stepError,
                //     executionTime: Date.now() - stepStartTime,
                //     timestamp: new Date().toISOString(),
                // });
            }

            // Store result
            const stepResult = {
                step: i,
                method: jsonData.method || jsonData.description || "action",
                action: jsonData.action || jsonData.description,
                status: stepStatus,
                error: stepError,
                data: stepData,
                timestamp: new Date().toISOString(),
            };

            results.push(stepResult);

            // Stop on critical errors
            if (
                stepStatus === "error" &&
                (stepError.includes("timeout") ||
                    stepError.includes("connection") ||
                    options.stopOnError === true)
            ) {
                // await sendToClient(connectionId, {
                //     type: "log",
                //     message: "🛑 Stopping workflow due to error",
                //     timestamp: new Date().toISOString(),
                // });
                break;
            }
        }

        return results;
    } catch (error) {
        await sendToClient(connectionId, {
            type: "log",
            message: `💥 Error: ${error.message}`,
            timestamp: new Date().toISOString(),
        });
        throw error;
    } finally {
        // Cleanup với streaming
        if (stagehand && isInitialized) {
            try {
                // await sendToClient(connectionId, {
                //     type: "log",
                //     message: "🧹 Cleaning up...",
                //     timestamp: new Date().toISOString(),
                // });

                const cleanupTimeout = new Promise((resolve) =>
                    setTimeout(resolve, 5000)
                );
                const cleanupPromise = stagehand.close();

                await Promise.race([cleanupPromise, cleanupTimeout]);

                // await sendToClient(connectionId, {
                //     type: "log",
                //     message: "✅ Cleanup completed",
                //     timestamp: new Date().toISOString(),
                // });
            } catch (closeError) {
                // await sendToClient(connectionId, {
                //     type: "log",
                //     message: `⚠️ Cleanup error: ${closeError.message}`,
                //     timestamp: new Date().toISOString(),
                // });
            }
        }
    }
}

/**
 * Execute step safely
 */
async function executeStepSafe(page, stepData) {
    try {
        if (
            stepData.method === "navigate" ||
            stepData.description === "navigate"
        ) {
            const url = stepData.arguments?.[0] || stepData.url;
            if (!url) throw new Error("URL is required for navigate action");

            await page.goto(url, {
                waitUntil: "domcontentloaded",
                timeout: 15000,
            });
        } else if (stepData.action) {
            await page.act(stepData.action);
        } else if (stepData.method) {
            await executeMethodStep(page, stepData);
        } else {
            const actionString =
                typeof stepData === "string"
                    ? stepData
                    : JSON.stringify(stepData);
            await page.act(actionString);
        }
    } catch (error) {
        throw new Error(`Step execution failed: ${error.message}`);
    }
}

/**
 * Execute method-based step
 */
async function executeMethodStep(page, stepData) {
    const { method, arguments: args = [], selector = "" } = stepData;

    switch (method.toLowerCase()) {
        case "click":
            if (selector) {
                await page.click(selector);
            } else if (args[0]) {
                await page.act(`click on ${args[0]}`);
            } else {
                throw new Error("Target required for click");
            }
            break;

        case "type":
        case "fill":
            const target = selector || args[0];
            const text = args[1] || args[0];
            if (!target || !text)
                throw new Error("Target and text required for type");

            await page.act(`type "${text}" into ${target}`);
            break;

        case "extract":
            const instruction = args[0] || selector;
            if (!instruction)
                throw new Error("Instruction required for extract");

            return await page.extract({ instruction });

        case "wait":
            const waitTime = Math.min(args[0] || 1000, 10000); // Max 10s wait
            await new Promise((resolve) => setTimeout(resolve, waitTime));
            break;

        default:
            await page.act(`${method} ${args.join(" ")} ${selector}`.trim());
    }
}

/**
 * Send message to WebSocket client
 */
async function sendToClient(connectionId, data) {
    try {
        const command = new PostToConnectionCommand({
            ConnectionId: connectionId,
            Data: JSON.stringify(data),
        });

        await apiGatewayClient.send(command);
    } catch (error) {
        if (error.statusCode === 410) {
            console.log(`Connection ${connectionId} is stale`);
        } else {
            console.error("Error sending to client:", error);
        }
    }
}

/**
 * Create Lambda response
 */
function createResponse(statusCode, body) {
    return {
        statusCode,
        body: JSON.stringify(body),
    };
}

/**
 * Example WebSocket message format:
 *
 * Send to Lambda:
 * {
 *   "action": "stagehand",
 *   "cdpUrl": "wss://connect.steel.dev?apiKey=...",
 *   "workflow": [
 *     {"description": "navigate", "method": "navigate", "arguments": ["https://youtube.com/"], "selector": ""},
 *     {"action": "click on the search box"}
 *   ],
 *   "options": {
 *     "stopOnError": true
 *   }
 * }
 *
 * Receive from Lambda:
 * - {"type": "connection", "message": "Connected", "connectionId": "xxx"}
 * - {"type": "start", "message": "Starting workflow", "workflow": [...]}
 * - {"type": "log", "message": "🔗 Connecting to browser..."}
 * - {"type": "step_start", "step": 1, "total": 2, "action": "navigate"}
 * - {"type": "step_complete", "step": 1, "status": "success"}
 * - {"type": "complete", "summary": {...}, "results": [...]}
 * - {"type": "error", "error": "Error message"}
 */
